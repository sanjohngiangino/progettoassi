class SonggoersController < ApplicationController
        skip_before_action :check_user_logged_in
        def show
        end
end

class Canzone<ActiveRecord::Base
  belongs_to :song
  belongs_to :songgoer
end
